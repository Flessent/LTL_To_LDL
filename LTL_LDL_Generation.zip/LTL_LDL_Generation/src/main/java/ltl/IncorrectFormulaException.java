package ltl;

public class IncorrectFormulaException extends Exception{

	 public IncorrectFormulaException(String errorMessage) {
	        super(errorMessage);
	    }
}
